#!/bin/bash

echo "🔧 Setting up Nginx with SSL for Evolution API..."

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Variables
DOMAIN="evo.istn.ac.id"
EMAIL="admin@istn.ac.id"

# Update system
print_status "Updating system packages..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq

# Install Nginx
print_status "Installing Nginx..."
apt-get install -y nginx

# Install Certbot for Let's Encrypt
print_status "Installing Certbot..."
apt-get install -y certbot python3-certbot-nginx

# Create web root directory
print_status "Creating web root directory..."
mkdir -p /var/www/html

# Stop Nginx temporarily
print_status "Stopping Nginx temporarily..."
systemctl stop nginx

# Obtain SSL certificate
print_status "Obtaining SSL certificate for $DOMAIN..."
certbot certonly --standalone -d $DOMAIN --email $EMAIL --agree-tos --non-interactive

# Copy Nginx configuration
print_status "Setting up Nginx configuration..."
cp evo.istn.ac.id.conf /etc/nginx/sites-available/
ln -sf /etc/nginx/sites-available/evo.istn.ac.id.conf /etc/nginx/sites-enabled/

# Remove default Nginx site
rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
print_status "Testing Nginx configuration..."
nginx -t

if [ $? -eq 0 ]; then
    print_status "Nginx configuration is valid"
else
    print_error "Nginx configuration has errors"
    exit 1
fi

# Start and enable Nginx
print_status "Starting Nginx..."
systemctl start nginx
systemctl enable nginx

# Setup automatic certificate renewal
print_status "Setting up automatic certificate renewal..."
echo "0 12 * * * /usr/bin/certbot renew --quiet" | crontab -

# Configure firewall
print_status "Configuring firewall..."
ufw allow 'Nginx Full'
ufw allow OpenSSH
ufw --force enable

# Test SSL certificate
print_status "Testing SSL certificate..."
sleep 5
curl -I https://$DOMAIN

if [ $? -eq 0 ]; then
    print_status "✅ SSL setup completed successfully!"
    echo ""
    echo "🎉 Evolution API is now available at:"
    echo "🌐 HTTPS: https://$DOMAIN"
    echo "🔒 SSL Certificate: Valid and active"
    echo "🔄 Auto-renewal: Configured"
    echo ""
    echo "📋 Service status:"
    systemctl status nginx --no-pager -l
    echo ""
    echo "🔍 Certificate info:"
    certbot certificates
else
    print_error "❌ SSL setup failed or domain not accessible"
fi
